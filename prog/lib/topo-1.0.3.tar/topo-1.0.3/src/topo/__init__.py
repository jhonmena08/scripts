def main() -> None:
    print("Hello from topo!")
